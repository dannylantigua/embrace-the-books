package com.agencyport.sdktraining.connectors.popquiz;

import java.util.logging.Logger;

import com.agencyport.connector.ConnectorDataBundle;
import com.agencyport.connector.IConnectorConstants;
import com.agencyport.connector.Outcome;
import com.agencyport.connector.impl.ConnectorManager;
import com.agencyport.fieldvalidation.validators.BaseValidator;
import com.agencyport.logging.LoggingManager;
import com.agencyport.shared.APException;
import com.agencyport.webshared.HTMLDataContainer;
import com.agencyport.workerscomp.servlets.CMDDisplayAcord130PDF;

public class FauxDBQueryConnector extends ConnectorManager {
	
	private static Logger logger = 
		LoggingManager.getLogger(FauxDBQueryConnector.class.getPackage().getName());

	
	protected boolean doPostProcess = true; // standard return value for postProcess method
	protected boolean interpretPresenceOfErrorMessagesAsErrorCondition = true; // default return value for corresponding method

	@Override
	public Outcome execute(ConnectorDataBundle dataBundle) throws APException {
		if( haveResults( dataBundle )) {
			logger.info( "CONDITIONS_MET");
			// getMessageMap().addMessage(IConnectorConstants.MESSAGE_WARNING_LITERAL, null, null, this.getClass().getSimpleName() + " results");
			// getMessageMap().addMessage(IConnectorConstants.MESSAGE_ERROR_LITERAL, null, null, this.getClass().getSimpleName() + " results");
			// doPostProcess = false;
			return Outcome.CONDITIONS_MET;
		}
		else {
			logger.info( "CONDITIONS_NOT_MET");
			// getMessageMap().addMessage(IConnectorConstants.MESSAGE_INFO_LITERAL, null, null, this.getClass().getSimpleName() + " NO results");
			// doPostProcess = true;
			return Outcome.CONDITIONS_NOT_MET;
		}
	}

	@Override
	public boolean postProcess(ConnectorDataBundle dataBundle) {
		return doPostProcess;
	}
	
	

	@Override
	public boolean interpretPresenceOfErrorMessagesAsErrorCondition() {
		// set a breakpoint and change the value to test non-standard behavior
		return interpretPresenceOfErrorMessagesAsErrorCondition;
	}

	protected boolean haveResults(ConnectorDataBundle dataBundle) {
		// to provide direct user control for testing purposes, the results are driven by input field
		HTMLDataContainer htmldc = dataBundle.getHTMLDataContainer();
		String results = htmldc.getStringValue("SP.FauxDBQueryResults");
		return !BaseValidator.checkIsEmpty(results);
	}


}
